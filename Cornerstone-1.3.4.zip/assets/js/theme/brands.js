import PageManager from '../page-manager';

export default class Brands extends PageManager {}
